
console.log(gQ.version() + ' ----  -----');


gQ.start = function(){
	console.log(gQ('li'));
	console.log(jQuery.makeArray($('li')));
};













