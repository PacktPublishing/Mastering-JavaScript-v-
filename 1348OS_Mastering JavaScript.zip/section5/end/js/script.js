
console.log(gQ.version() + ' ----  -----');


gQ.start = function(){

	gQ('#msg').text('change my copy');
	//gQ('li').text('update me');

	console.log(gQ('#msg').adapter);
};













