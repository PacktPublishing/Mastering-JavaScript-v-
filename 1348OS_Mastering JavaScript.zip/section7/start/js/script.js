
console.log(gQ.version() + ' ----  -----');


gQ.start = function(){

	gQ('#msg').text(Math.round(new Date().getTime()/1000));

};













