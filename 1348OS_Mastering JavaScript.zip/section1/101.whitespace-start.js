var name='Ben',
var sur='Fhala';

if(a>b)doSomething();

for (var i=0;i<100;i++)doSomething();
