/* anml - Animal */

var anmlCat = new com.o2GEEK.Animal('cat'),
		VERSION = '1.00';
//const VERSION;


var com = com || {};
		com.o2GEEK = com.o2GEEK || {};


var com.o2GEEK.Animal = function(type){

}

com.o2GEEK.Animal.prototype.VERSION = '1.00';
