function action(a, b, c){
	var myName, 
			max,
			sum,
			isDay;

	if(isDay)
		doDayStuff();
	
	action2();
	action3();
}